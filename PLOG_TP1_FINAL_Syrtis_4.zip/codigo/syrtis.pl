:- include('Interface.pl').
:- include('Utilitarios.pl').
:- include('Logica.pl').
:- include('Menus.pl').


%--------------------------------%
%--------Syrtis em ProLog--------%
%--------------------------------%
%------- escreva syrtis. --------%
%---- na consola para correr ----%
%--------------------------------%
%--------------------------------%


syrtis :-
	limpaEcra,
	menuPrincipal.





	